The test.py file is designed to test result and output files. 
The files must already exist and the correct corresponding file paths provided for the unittest to 
run accurately.